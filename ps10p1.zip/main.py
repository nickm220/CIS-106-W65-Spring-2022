def displaynames(lastn):
  for i in lastn:
    print(i)
def displayr(lastn):
  l = len(lastn)
  print("Arrays in Reverse Order ")
  for y in range (l-1,-1, -1):
    print(lastn[y])


f = open("lnames.txt", "r")

lastn = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  lastname = f.readline()
f.close()
displaynames(lastn)
displayr(lastn)