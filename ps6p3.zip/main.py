 last f = open("pd3.txt", "r")

totalb = 0.0

lname = str(f.readline().rstrip('\n'))

while lname !="":
  salary = float(f.readline())

  if salary >= 100000:
    bonus = .20
  elif salary == 50000:
    bonus = .15
  else:
    bonus = .10

  bonus = bonus * salary
  totalb = totalb + bonus

  print("Employee last name is ", lname)
  print("Their salary is ", salary)
  print("Their bonus is ", bonus)

  lname = str(f.readline().rstrip('\n'))

print("The sum of all bonuses is ", totalb)