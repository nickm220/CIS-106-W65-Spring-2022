#nickmoffa
qty = float(input("Enter number of concert tickets "))

if qty >= 25:
  price = 50.00
elif qty >= 10 and qty <= 24:
  price = 60.00
elif qty >= 5 and qty <= 9:
  price = 70.00
elif qty < 5:
  price = 75.00

total = qty * price

print("The number of tickets are ", qty)
print("The price per ticket is ", price)
print("The total cost is ", total)