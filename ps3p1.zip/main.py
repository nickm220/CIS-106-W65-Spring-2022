#nickmoffa
quantity = float(input("Enter quantity to order "))

if quantity >=1000:
  up = 3.00
else:
  up = 5.00
  
extprice = quantity * up

tax = extprice * 0.07

total = tax + extprice

print("Quantity is: ", quantity)
print("Unit price is: ", up)
print("Extended price is: ", extprice)
print("Tax is: ", tax)
print("The total is: ", total)