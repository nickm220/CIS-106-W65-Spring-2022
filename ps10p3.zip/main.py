#nickmoffa
def  hilow(lastn, score):
  l = len(lastn)
  hiscore = -1.0
  lowscore = 999
  for y in range (0,l,1):
    if float(score[y]) > float(hiscore):
      hiindex = y 
      hiscore = score [y]

    if float(score[y]) < float(lowscore):
      loindex = y
      lowscore = score[y]

  print("Highest salary ", lastn[hiindex], score[hiindex])
  print("Lowest salary ", lastn[loindex], score[loindex])

f = open("lname.txt", "r")

lastn = []
score = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()
f.close()

hilow(lastn, score)