#nickmoffa

def compboth(sales):
  if sales > 100000:
    perct = .10
  else:
    perct = .05

  comm = sales * perct
  nxttgt = sales * .05

  return comm, nxttgt

lname = input("Enter last name ")
sales = float(input("Enter sales "))

comm, nxttgt = compboth(sales)

print("Salesperson last name ", lname)
print("Commission is ", comm)
print("Next year's target is ", nxttgt)