#nickmoffa
def rate(code):
  if code == "L":
    rate = 25
  elif code == "A":
    rate = 30
  elif code == "J": 
    rate = 50

  return rate

lname = input("Enter last name ")
code = input("Enter job code (L, A, or J) ")
hours = float(input("Enter hours worked "))

rate = rate(code)

def gross(hours, rate):
  if hours > 40:
    gross = (float (hours) - 40) * 1.5 * float (rate) + 40 * float (rate)
  else:
    gross = float (rate) * float (hours)

  return gross

gross = gross(hours, rate)

print("Last name ", lname)
print("Gross pay is ", gross)
  
    