#nickmoffa
def mpg(miles, gallons):
  mpg = float(miles) / float (gallons)

  return mpg

def cost(gallons):
  cost = gallons * 2.50

  return cost

city = input("Enter destination city ")
miles = float(input("Enter miles travelled "))
gallons = float(input("Enter gallons used "))

mpg = mpg(miles,gallons)
cost = cost(gallons)

print("Destination ", city)
print("Miles per gallon is ", mpg)
print("Cost of gas is ", cost)