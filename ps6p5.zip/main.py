f = open("pd5.txt", "r")

c = 0.0
totalt = 0.0

lname = str(f.readline().rstrip('\n'))

while lname !="":
  code = str(f.readline())
  credits = float(f.readline())
  
  if code == "I":
    cost = 250
  else: 
    cost = 550

  tuition = cost * credits 

  totalt = totalt + tuition
  c = c + 1

  print("Student last name is ", lname)
  print("Credits taken ", credits)
  print("Tuition Owed ", tuition)

  lname = str(f.readline().rstrip('\n'))

print("Sum of all tuitions ", totalt)
print("Total number of students is ", c)