#nickmoffa
def compprice(miles):

  if miles >= 30:
    price = 12
  elif miles >= 20 and miles <= 29:
    price = 10
  elif miles >= 10 and miles <= 19:
    price = 8
  else:
    price = 5

  return price 

response = input("Want to calculate ticket price Yes or No ")

tottickets = 0

while response == "Yes": 
  lname = input("Enter last name ")
  miles = float(input("Enter miles from downtown Chicago "))
  
  price = compprice(miles)

  tottickets = tottickets + price
  
  print("The ticket price is ", price)

  response = input("Want to calculate next month's sales Yes or No ")

print("Sum of all tickets is ", tottickets)