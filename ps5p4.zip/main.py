#nickmoffa
counter = 0  
totalgross = 0

response = input("Want to calculate gross pay Yes or No ")

while response == "Yes":
  counter = counter + 1
  lastname = input("Enter employee last name ")
  hours = float(input("Enter hours worked "))
  rate = float(input("Enter rate of pay "))
  if hours > 40:
    gross = (hours - 40) * 1.5 * rate + 40 * rate
  else:
    gross = rate * hours
  totalgross = totalgross + gross
  
  print("Employee last ", lastname)
  print("Gross pay is ", gross)
  response = input("Want to calculate gross pay Yes or No ")

avg = totalgross / counter
print("The sum of all gross pay is ", totalgross)
print("The number of employees is ", counter)
print("The average is ", avg)