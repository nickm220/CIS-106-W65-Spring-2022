#nickmoffa

def compboth(exam1, exam2, exam3):
  avg = (exam1 + exam2 + exam3) / 3
  totpoints = exam1 + exam2 + exam3

  return avg, totpoints

lname = input("Enter last name ")
exam1 = float(input("Enter exam score one "))
exam2 = float(input("Enter exam score two "))
exam3 = float(input("Enter exam score three "))

avg, totpoints = compboth(exam1, exam2, exam3)

print("Student last name is ", lname)
print("Total points are ", totpoints)
print("Average exam score is ", avg)