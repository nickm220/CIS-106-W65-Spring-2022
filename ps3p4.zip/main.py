#nickmoffa
name = input("Enter name of appliance ")
cost = float(input("Enter cost of appliance "))

if cost > 1000:
  warranty = cost * 0.1
else:
  warranty = cost * .05

total = cost + warranty

print(name, "costs ", cost)
print("The cost of the warranty is ", warranty)
print("The total cost is ", total)