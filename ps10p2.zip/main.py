def displaynames(lastn, score):
  for i in lastn, score:
    print(i)
def displayr(lastn, score):
  l = len(lastn)
  print("Arrays in Reverse Order ")
  for y in range (l-1,-1, -1):
    print(lastn[y])
  print("Display array using for loop controls ")
  for x in range(0,l,1):
    print(x, " ", lastn[x], " ", score[x])


f = open("lnames.txt", "r")

lastn = []
score = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()
f.close()
displaynames(lastn, score)
displayr(lastn, score)