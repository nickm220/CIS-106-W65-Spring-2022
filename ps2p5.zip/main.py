# nick moffa
price = float(input("Enter price of item "))
discount = float(input("Enter discount percent in deciaml form "))

discountamt = discount*price
discountprice = price-discountamt

print ("The discount amount is ",discountamt)
print ("The discounted price is ",discountprice)