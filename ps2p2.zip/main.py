# nick moffa
lname = input("Enter last name ")
hours = float(input("Enter hours worked "))
rate = float(input("Enter rate "))

grosspay = hours*rate

print ("Last name is",lname)
print ("Your gross pay is ",grosspay)