#nickmoffa
sum = 0

response = input("Want to calculate the discount Yes or No ")

while response == "Yes":
  qty = float(input("Enter quantity "))
  price = float(input("Enter price of item "))

  extp = qty * price

  if extp > 10000:
    disc = .25
  else:
    disc = .10

  discamt = extp * disc
  total = extp - discamt
  sum = sum + discamt

  print("The extended price is ", extp)
  print("The discount amount is ", discamt)
  print("The total is ", total)
  response = input("Want to calculate the discount Yes or No ")

print("The sum of all the discounts is", sum)