#DL1
def dl1 (thelist):
  n = int(input("Enter number of items in your list "))
  for n in range (0,n,1):
    s = int(input("Enter an integer "))
    thelist.append(s)
  return thelist 
def displaylist(thelist):
  for item in thelist:
    print(item)

thelist = []
thelist = dl1(thelist)
print(thelist)

#DL2
thelist.insert(0,99)
print(thelist)

#DL3
thelist[0] = 100
print(thelist)

#DL4
thelist2 = ["500","600","700","800","900"]
print(thelist2)
thelist.extend(thelist2)
print(thelist)

#DL5
thelist2.remove("800")
print(thelist2)

#DL6
thelist2.remove("700")
print(thelist2)

#DL7&8
listgrade = ["A", "B", "C", "A", "A", "C"]
print(listgrade.count("A"))

#DL9
print(listgrade.index("B"))

#DL10
if "F" in listgrade:
  print("ok")
else:
  print("F Not in list")

#DL11
thelist2.clear()
print(thelist2)

#DL13&14
playerlist = ["Rizzo", "Davis", "Baez", "Happ", "Bryan"]
playerlist.sort()
print(playerlist)

#DL15
playerlist2 = ["Rizzo", "Davis", "Baez", "Happ", "Bryan"]
print(playerlist2)

#DL16
playerlist2.reverse()
print(playerlist2)

#DL12
del thelist2
print(thelist2)