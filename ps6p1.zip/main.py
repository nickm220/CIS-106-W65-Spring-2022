#nickmoffa
response = input("Want to compute interest? Yes or No ")

totint = 0

while response == "Yes":
  p = float(input("Enter principle "))
  r = float(input("Enter interest rate "))
  
  for count in range (1, 6, ):
    i = p * r 
    eb = p + i 
    print(count, "   ", p, "  ", eb)
    p = eb

    totint = totint + i 
  
  print("Total interest earned is ", totint)
  
  response = input("Want to compute interest? Yes or No ")
  