#nickmoffa
def tuition(hours, code):
  if code == "I":
    tuition = 250
  elif code == "O":
    tuition = 550

  tuition = tuition * hours

  return tuition

lname = input("Enter last name ")
hours = float(input("Enter credit hours "))
code = input("Enter district code (I or O) ")

tuition = tuition(hours,code)

print("Last name ", lname)
print("Tuition owed is ", tuition)