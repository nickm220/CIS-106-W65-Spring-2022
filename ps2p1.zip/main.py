#nick moffa
quantity = float(input("enter quantity "))
price = float (input("enter price "))

extended = quantity*price

print ("Extended Price is ",extended)