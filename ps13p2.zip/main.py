
class Student:
  def __init__(self, first, last, code, credits):
    self.first = first
    self.last = last
    self.code = code
    self.credits = credits
  
  def comptuition(self):
    if self.code == "I":
      tuition = 250.00
    else:
      tuition = 500.00

    tuition = tuition * self.credits 
    return tuition

stu_1 = Student('Corey', 'Schafer', 'I', 15)

print(stu_1.first)
print(stu_1.last)
print(stu_1.code)
print(stu_1.credits)
print(stu_1.comptuition())