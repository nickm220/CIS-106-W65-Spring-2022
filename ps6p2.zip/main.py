#nickmoffa
a = 1 
b = 0 

for count in range (1,20,1):
  c = a + b

  print(c)

  a = b 
  b = c