#nickmoffa

response = input("Want to calculate average score Yes or No ")

while response == "Yes": 
  length = float(input("Enter length of room "))
  width = float(input("Enter width of room "))
  height = float(input("Enter height of room "))
  
  def squft(length, width, height):
    squft = 2 * length * width + 2 * length * height + 2 * width * height

    return squft

  squft = squft(length, width, height)
  numbgal = squft / 50
  
  print("The number of gallons needed is ", numbgal)

  response = input("Want to calculate average score Yes or No ")