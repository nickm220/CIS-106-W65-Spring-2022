#nickmoffa
def nxt(month, sales):
    
    if month == "Jan" or month == "Feb" or month == "Mar":
      forecast = .10
    elif month == "Apr" or month == "May" or month == "Jun":
      forecast = .15
    elif month == "Jul" or month == "Aug" or month == "Sep":
      forecast = .20
    else:
      forecast = .25
  
    nxt = sales * (1 + forecast)

    return nxt 

response = input("Want to calculate next month's sales Yes or No ")

while response == "Yes": 
  lname = input("Enter last name ")
  month = input("Enter month abbreviation ")
  sales = float(input("Enter sales "))
  
  nxt = nxt(month, sales)
  
  print("Next month's sales is ", nxt)

  response = input("Want to calculate next month's sales Yes or No ")