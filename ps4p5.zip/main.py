#nickmoffa
lname = input("Enter last name ")
salary = float(input("Enter salary "))
joblvl = float(input("Enter job level "))

if joblvl >= 10:
  bonusrate = 0.25
elif joblvl >=5 and joblvl <= 9:
  bonusrate = 0.20
else:
  bonusrate = 0.10

bonus = salary * bonusrate

print("Employee last name is ", lname)
print("Bonus is ", bonus)