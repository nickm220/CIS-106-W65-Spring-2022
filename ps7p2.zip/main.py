#nickmoffa
def battingavg(hits, bats):
  avg = float(hits) / float(bats)

  return avg

lname = input("Enter last name ")
hits = float(input("Enter number of hits "))
bats = float(input("Enter at bats "))

avg = battingavg(hits,bats)

print("Last name ", lname)
print("Batting average is ", avg)