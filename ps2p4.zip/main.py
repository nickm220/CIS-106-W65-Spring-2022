# nick moffa 
lname = input("Enter last name ")
credits = float(input("Enter credits taken "))

tuition = credits*250+100
print ("Last name is ",lname)

print ("Tuition cost is ",tuition)