#nickmoffa
books = float(input("Enter number of books to order "))
cost = float(input("Enter cost per book "))

total = cost * books

if total > 50: 
  shipping = 0
else:
  shipping = 25

print("The shipping charge is ", shipping)
print("The order total is ", total)