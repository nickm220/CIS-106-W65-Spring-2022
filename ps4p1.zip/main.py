#nickmoffa
qty = float(input("Enter quantity "))

if qty > 10000:
  price = 10.00
elif qty >= 5000 and qty<= 10000:
  price = 20.00
elif qty < 5000:
  price = 30.00

extp = qty * price
tax = extp * 0.07
total = tax + extp

print("Extended price is ", extp)
print("tax amount is ", tax)
print("The total is ", total)