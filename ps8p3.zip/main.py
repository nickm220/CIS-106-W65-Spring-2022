#nickmoffa
def compprice(stickp, make, model, code):
    
  if make == "Honda" and model == "Accord":
    perctoff = .10
  elif make == "Toyota" and model == "Rav4":
    perctoff = .15
  elif code == "Y":
    perctoff = .30
  else:
    perctoff = .05
  
  newstickp = stickp * (1 - perctoff)
  tax = newstickp * .07
  total = newstickp + tax

  return total

response = input("Want to calculate percent off sticker price Yes or No ")

sumtotal = 0

while response == "Yes": 
  make = input("Enter the make ")
  model = input("Enter the model ")
  code = input("Is the car electric Y or N ")
  stickp = float(input("Enter sticker price "))

  total = compprice(stickp, make, model, code)
  sumtotal = sumtotal + total

  print("The price out the door is ", total)

  response = input("Want to calculate percent off sticker price Yes or No ")

print("The sum of all cars is ", sumtotal)
  