# nick moffa 
length = float(input("Enter length "))
width = float(input("Enter width "))

area = length*width
circumference = 2*length+2*width

print ("The area is ",area)
print ("The circumference is ",circumference)