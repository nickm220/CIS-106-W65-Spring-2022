#nickmoffa
def compvalue(county, mv):
  if county == "Cook":
    avp = 0.90
  elif county == "DuPage":
    avp = 0.80
  elif county == "McHenry":
    avp = 0.75
  elif county == "Kane":
    avp = 0.60
  else:
    avp = 0.70

  value = mv * avp

  return value 

response = input("Do you want to calculate assessed value Yes or No ")

totalav = 0
totalmv = 0

while response == "Yes":
  county = input("Enter the county ")
  mv = float(input("Enter the market value of home "))

  value = compvalue(county, mv)

  print("The assessed value is ", value)

  totalav = totalav + value
  totalmv = totalmv + mv

  response = input("Do you want to calculate assessed value Yes or No ")

print("The sum of assessed values is ", totalav)
print("The sum of market values is ", totalmv)