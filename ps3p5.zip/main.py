#nickmoffa
lname = input("Enter lname ")
depen = float(input("Enter number of dependents "))
gross = float(input("Enter gross income "))

adjgross = gross - (depen * 12000) 

if adjgross > 50000:
    taxrate = .2
else:
  taxrate = .1

incometax = adjgross * taxrate

if incometax < 0:
  incometax = 100
else:
  incometax = incometax

print("Last name is ", lname)
print("Gross income is ", gross)
print("The number of dependents are ", depen)
print("Adjusted gross income is ", adjgross)
print("Income tax is ", incometax)
  