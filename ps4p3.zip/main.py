#nickmoffa
prin = float(input("Enter principle amount "))
matur = float(input("Enter year to maturity "))

if prin > 100000 and matur == 5:
  intrate = 0.06
elif prin >= 50000 and prin <= 100000 and matur == 10:
  intrate = 0.05
elif prin >= 50000 and prin <= 100000 and matur == 5:
  intrate = 0.04
else:
  intrate = 0.02

frstint = prin * intrate

print("The principle is ", prin)
print("The interest rate is ", intrate)
print("The interest amount for the first year is ", frstint)