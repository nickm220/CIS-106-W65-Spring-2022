#nickmoffa

def compboth(s1, s2, s3, hand):
  avg = (s1 + s2 + s3) / 3
  avgh = ((s1 + s2 + s3) / 3) - hand

  return avg, avgh

lname = input("Enter last name ")
s1 = float(input("Enter game score one "))
s2 = float(input("Enter game score two "))
s3 = float(input("Enter game score three "))
hand = float(input("Enter handicap "))

avg, avgh = compboth(s1, s2, s3, hand)

print("Last name ", lname)
print("Average score is ", avg)
print("Average score with handicap is ", avgh)