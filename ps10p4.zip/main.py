#nickmoffa
def displaynames(lastn, avg):
  for i in lastn, avg:
    print(i)

def seqsearch(lastn, sname):
  l = len(lastn)
  sindex = -1
  for y in range(0,l,1):
    if lastn[y] == sname:
      sindex = y

  return sindex
  
f = open("lnames.txt", "r")

lastn = []
avg = []

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  avg.append(s)
  lastname = f.readline()
f.close()
displaynames(lastn, avg)

response = input("Do you want to do this program Yes or No ")

while response == "Yes":
  sname = input("Enter last name to search for ")
  i = seqsearch(lastn, sname)
  print(lastn[i], " batting average of ", avg[i])

  response = input("Do you want to do this program Yes or No ")