#nickmoffa
item = input("Enter item to order (A or B) ")
qty = float(input("Enter quantity to order "))

if item == "A":
  up = 10.00
else:
  up = 20.00

extprice = up * qty

print("Item ordered is: ", item)
print("Unit price: ", up)
print("Extended price: ", extprice)