# nickmoffa

def compboth(quantity, price, discrate):
  total = price * qty
  discamt = total * discrate
  discprice = total - discamt 

  return discamt, discprice 

qty = float(input("Enter quantity "))
price = float(input("Enter price "))
discrate = float(input("Enter discount rate "))

discamt, discprice = compboth(qty, price, discrate)

print("The quantity is ", qty)
print("The price is ", price)
print("The discount amount is ", discamt)
print("The discounted price is ", discprice)