#nickmoffa

total = 0
tax = 0

def compboth(qty, price):
  global total
  total = qty * price 
  global tax
  tax = total * .07

qty = float(input("Enter quantity "))
price = float(input("Enter unit price "))

compboth(qty, price)

print("The total is ", total)
print("The tax is ", tax)